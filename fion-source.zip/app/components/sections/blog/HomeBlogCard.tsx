import Link from "next/link";

import type {
  BlogPost,
} from "@/features/blog/blog.types";

type HomeBlogCardProps = {
  post: BlogPost;
};

function truncateText(
  value: string,
  maxLength: number,
) {
  const clean = value
    .replace(/\s+/g, " ")
    .trim();

  if (
    clean.length <=
    maxLength
  ) {
    return clean;
  }

  return `${clean
    .slice(
      0,
      maxLength - 1,
    )
    .trimEnd()}…`;
}

export default function HomeBlogCard({
  post,
}: HomeBlogCardProps) {
  const shortTitle =
    truncateText(
      post.title,
      20,
    );

  const shortExcerpt =
    truncateText(
      post.excerpt,
      40,
    );

  return (
    <article
      className="
        group
        overflow-hidden

        border
        border-white/10

        bg-[#080808]

        transition-all
        duration-500

        hover:border-[#591323]
        hover:bg-[#0b0b0b]
      "
    >
      <Link
        href={`/blog/${post.slug}`}
        className="block"
      >
        {/* IMAGE */}

        <div
          className="
            relative
            aspect-[16/10]
            overflow-hidden

            border-b
            border-white/10

            bg-[#0d0d0d]
          "
        >
          {post.coverImageUrl ? (
            <img
              src={
                post.coverImageUrl
              }
              alt=""
              className="
                h-full
                w-full
                object-cover

                opacity-80

                transition-all
                duration-700

                group-hover:scale-[1.025]
                group-hover:opacity-100
              "
            />
          ) : (
            <div
              className="
                flex
                h-full
                items-center
                justify-center
              "
            >
              <span
                className="
                  font-serif
                  text-[clamp(3rem,7vw,6rem)]
                  italic
                  tracking-[-0.06em]
                  text-[#591323]
                "
              >
                Fion.
              </span>
            </div>
          )}

          {/* CATEGORY */}

          <span
            className="
              absolute
              left-4
              top-4

              border
              border-white/15

              bg-black/80

              px-3
              py-2

              text-[9px]
              font-medium
              uppercase
              tracking-[0.16em]

              text-[#f4efe9]

              backdrop-blur-md
            "
          >
            {post.category}
          </span>
        </div>

        {/* COPY */}

        <div
          className="
            flex
            min-h-[190px]
            flex-col

            p-6
            sm:p-7
          "
        >
          <h3
            className="
              font-serif

              text-[clamp(2rem,3vw,3rem)]

              leading-[0.92]
              tracking-[-0.05em]

              text-[#f4efe9]
            "
          >
            {shortTitle}
          </h3>

          <p
            className="
              mt-4

              text-[13px]
              leading-6

              text-[#aaa19e]
            "
          >
            {shortExcerpt}
          </p>

          <div
            className="
              mt-auto
              flex
              justify-end

              pt-7
            "
          >
            <span
              className="
                text-lg
                text-[#c45a78]

                transition-transform
                duration-300

                group-hover:translate-x-1
              "
            >
              →
            </span>
          </div>
        </div>
      </Link>
    </article>
  );
}