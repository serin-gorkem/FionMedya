import Link from "next/link";

import WineLane from "@/app/components/ui/WineLane";
import SectionContainer from "@/app/components/ui/SectionContainer";
import SectionEyebrow from "@/app/components/ui/SectionEyebrow";

import {
  createBlogService,
} from "@/features/blog/blog.server";

import HomeBlogCard from "./HomeBlogCard";

export default async function BlogSection() {
  const service =
    await createBlogService();

  /*
   * Homepage maksimum
   * iki yazı gösterir.
   */
  const posts =
    await service.getPublished(
      2,
    );

  if (
    posts.length === 0
  ) {
    return null;
  }

  return (
    <section
      id="blog"
      aria-labelledby="home-blog-title"
      className="
        relative
        overflow-hidden

        border-t
        border-white/10

        bg-black
      "
    >
      <WineLane />

      <SectionContainer>
        {/* INTRO */}

        <div
          className="
            relative
            z-20

            xl:grid
            xl:grid-cols-[minmax(0,1fr)_460px_minmax(0,1fr)]
            xl:gap-10
          "
        >
          {/* LEFT */}

          <div>
            <SectionEyebrow>
              Fion Journal
            </SectionEyebrow>

            <h2
              id="home-blog-title"
              className="
                mt-6

                max-w-[570px]

                font-serif

                text-[clamp(3.8rem,6vw,6.8rem)]

                leading-[0.84]
                tracking-[-0.06em]

                text-[#f4efe9]
              "
            >
              Fikirler.
              <br />

              <span className="text-white/65">
                Notlar.
              </span>
              <br />

              <em className="text-[#c45a78]">
                Deneyim.
              </em>
            </h2>
          </div>

          {/* EMPTY LANE */}

          <div
            aria-hidden="true"
            className="hidden xl:block"
          />

          {/* RIGHT */}

          <div
            className="
              mt-12

              xl:mt-0
              xl:flex
              xl:items-end
              xl:justify-end
            "
          >
            <div className="max-w-[370px]">
              <p
                className="
                  font-serif

                  text-[clamp(1.7rem,2.4vw,2.6rem)]

                  leading-[1]
                  tracking-[-0.04em]

                  text-[#f4efe9]
                "
              >
                Bildiğimizi
                saklamıyoruz.
              </p>

              <p
                className="
                  mt-5

                  text-[14px]
                  leading-7

                  text-[#aaa19e]
                "
              >
                Sosyal medya,
                reklam ve tasarım
                üzerine kısa notlar.
              </p>
            </div>
          </div>
        </div>

        {/* POSTS */}

        <div
          className="
            relative
            z-20

            mt-20

            grid
            gap-6

            md:grid-cols-2

            xl:grid-cols-[minmax(0,1fr)_460px_minmax(0,1fr)]
            xl:gap-10
          "
        >
          {/* POST 1 */}

          <div>
            {posts[0] && (
              <HomeBlogCard
                post={posts[0]}
              />
            )}
          </div>

          {/* EMPTY WINE LANE */}

          <div
            aria-hidden="true"
            className="
              hidden
              xl:block
            "
          />

          {/* POST 2 */}

          <div>
            {posts[1] && (
              <HomeBlogCard
                post={posts[1]}
              />
            )}
          </div>
        </div>

        {/* ALL POSTS */}

        <div
          className="
            relative
            z-20

            mt-12

            flex
            justify-end

            border-t
            border-white/10

            pt-8
          "
        >
          <Link
            href="/blog"
            className="
              group

              inline-flex
              items-center
              gap-4

              text-[10px]
              font-medium
              uppercase
              tracking-[0.18em]

              text-[#f4efe9]
            "
          >
            Tüm yazıları gör

            <span
              className="
                text-[#c45a78]

                transition-transform
                duration-300

                group-hover:translate-x-1
              "
            >
              →
            </span>
          </Link>
        </div>
      </SectionContainer>
    </section>
  );
}