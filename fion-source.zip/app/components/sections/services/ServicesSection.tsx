import SectionContainer from "@/app/components/ui/SectionContainer";
import WineLane from "@/app/components/ui/WineLane";
import ServiceRow from "./ServiceRow";
import ServicesIntro from "./ServicesIntro";
import ServicesSummary from "./ServicesSummary";
import { services } from "./services.data";
import Link from "next/link";

export default function ServicesSection() {
  return (
    <section
      id="services"
      aria-labelledby="services-title"
      className="relative overflow-hidden border-t border-white/10 bg-black"
    >
      <WineLane />
      <SectionContainer>
        <ServicesIntro />
        <div className="space-y-24 xl:space-y-36">
          {services.map((service) => (
            <ServiceRow key={service.number} service={service} />
          ))}
        </div>
        <div
          className="
    relative
    z-20

    mt-16
    border-t
    border-white/10

    pt-8

    xl:grid
    xl:grid-cols-[minmax(0,1fr)_460px_minmax(0,1fr)]
    xl:gap-10
  "
        >
          <div>
            <p
              className="
        max-w-[360px]

        text-[12px]
        leading-6
        text-[var(--muted)]
      "
            >
              Sosyal medya, tasarım ve reklam hizmetlerimizi daha detaylı
              incele.
            </p>
          </div>

          {/* wine lane boş */}

          <div aria-hidden="true" className="hidden xl:block" />

          <div
            className="
      mt-8
      xl:mt-0
      xl:flex
      xl:justify-end
    "
          >
            <Link
              href="/hizmetler"
              className="
        group

        flex
        w-full
        max-w-[390px]

        items-center
        justify-between

        border-b
        border-white/20

        pb-4

        text-[10px]
        font-medium
        uppercase
        tracking-[0.18em]

        text-[var(--ivory)]

        transition-colors
        duration-300

        hover:border-[var(--wine-light)]
      "
            >
              Tüm hizmetleri incele
              <span
                className="
          text-[var(--wine-light)]

          transition-transform
          duration-300

          group-hover:translate-x-2
        "
              >
                →
              </span>
            </Link>
          </div>
        </div>
        <ServicesSummary />
      </SectionContainer>
    </section>
  );
}
