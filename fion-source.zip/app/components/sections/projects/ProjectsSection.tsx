import SectionContainer from "@/app/components/ui/SectionContainer";
import WineLane from "@/app/components/ui/WineLane";
import ProjectRow from "./ProjectRow";
import ProjectsIntro from "./ProjectsIntro";
import ProjectsOutro from "./ProjectsOutro";
import { projects } from "./projects.data";
import Link from "next/link";
export default function ProjectsSection() {
  return (
    <section
      id="projects"
      aria-labelledby="projects-title"
      className="relative overflow-hidden border-t border-white/10 bg-black"
    >
      <WineLane />
      <SectionContainer>
        <ProjectsIntro />
        <div className="space-y-28 xl:space-y-40">
          {projects.map((project) => (
            <ProjectRow key={project.number} project={project} />
          ))}
        </div>
        <div
          className="
    relative
    z-20

    mt-20
    border-t
    border-white/10

    pt-8

    xl:grid
    xl:grid-cols-[minmax(0,1fr)_460px_minmax(0,1fr)]
    xl:gap-10
  "
        >
          <div>
            <p
              className="
        max-w-[350px]

        text-[12px]
        leading-6
        text-[var(--muted)]
      "
            >
              Sonucu yalnızca anlatmıyoruz. Süreci ve işi de gösteriyoruz.
            </p>
          </div>

          <div aria-hidden="true" className="hidden xl:block" />

          <div
            className="
      mt-8
      xl:mt-0
      xl:flex
      xl:justify-end
    "
          >
            <Link
              href="/isler"
              className="
        group

        flex
        w-full
        max-w-[390px]

        items-center
        justify-between

        border-b
        border-white/20

        pb-4

        text-[10px]
        font-medium
        uppercase
        tracking-[0.18em]

        text-[var(--ivory)]

        transition-colors
        duration-300

        hover:border-[var(--wine-light)]
      "
            >
              Tüm işleri incele
              <span
                className="
          text-[var(--wine-light)]

          transition-transform
          duration-300

          group-hover:translate-x-2
        "
              >
                →
              </span>
            </Link>
          </div>
        </div>
        <ProjectsOutro />
      </SectionContainer>
    </section>
  );
}
