import type {
  Metadata,
} from "next";

import DetailPageShell from "@/app/components/pages/DetailPageShell";

export const metadata: Metadata = {
  title:
    "İşler | Fion Medya",

  description:
    "Fion Medya tarafından üretilen sosyal medya, reklam, tasarım ve dijital deneyim projeleri.",
};

export default function IslerPage() {
  return (
    <DetailPageShell
      eyebrow="Fion / İşler"
      title={
        <>
          Biz anlatmayalım.
          <br />

          <em className="text-[#b9b1ad]">
            İşler anlatsın.
          </em>
        </>
      }
      description="Stratejiden yaratıcı üretime, reklamdan dijital deneyime kadar gerçek markalar için ürettiğimiz çalışmalar."
    >
      <div className="space-y-0">
        {[
          {
            client: "FUYAPI",
            result:
              "Reklamdan ev satışına.",
            services:
              "Sosyal Medya + Reklam",
          },
          {
            client:
              "MOTO EXPRESS",
            result:
              "Dikkati harekete dönüştürdük.",
            services:
              "Sosyal Medya + Reklam",
          },
          {
            client:
              "CAFE ROMA",
            result:
              "Fiziksel deneyim, dijital dokunuş.",
            services:
              "Dijital Deneyim",
          },
        ].map(
          (
            project,
            index,
          ) => (
            <article
              key={
                project.client
              }
              className="
                grid
                gap-8
                border-t
                border-white/10
                py-12
                lg:grid-cols-[100px_220px_minmax(0,1fr)]
                lg:items-center
              "
            >
              <span
                className="
                  font-serif
                  text-2xl
                  text-white/35
                "
              >
                {(index + 1)
                  .toString()
                  .padStart(
                    2,
                    "0",
                  )}
              </span>

              <div>
                <p
                  className="
                    text-[10px]
                    uppercase
                    tracking-[0.2em]
                    text-[var(--wine-light)]
                  "
                >
                  {
                    project.client
                  }
                </p>

                <p
                  className="
                    mt-3
                    text-[12px]
                    text-[var(--muted)]
                  "
                >
                  {
                    project.services
                  }
                </p>
              </div>

              <h2
                className="
                  font-serif
                  text-[clamp(2.4rem,4vw,4.8rem)]
                  leading-[0.92]
                  tracking-[-0.05em]
                "
              >
                {project.result}
              </h2>
            </article>
          ),
        )}
      </div>
    </DetailPageShell>
  );
}