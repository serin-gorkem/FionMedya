import type {
  Metadata,
} from "next";

import DetailPageShell from "@/app/components/pages/DetailPageShell";

export const metadata: Metadata = {
  title:
    "Hizmetler | Fion Medya",

  description:
    "Fion Medya sosyal medya yönetimi, grafik tasarım ve dijital reklam yönetimi hizmetleri.",
};

export default function HizmetlerPage() {
  return (
    <DetailPageShell
      eyebrow="Fion / Hizmetler"
      title={
        <>
          Daha fazla değil.
          <br />

          <em className="text-[#b9b1ad]">
            Daha iyi.
          </em>
        </>
      }
      description="Sosyal medya, grafik tasarım ve dijital reklamı birbirinden ayrı işler gibi değil, aynı markanın parçaları olarak ele alıyoruz."
    >
      <div
        className="
          grid
          gap-px
          overflow-hidden
          rounded-[24px]
          border
          border-white/10
          bg-white/10
          lg:grid-cols-3
        "
      >
        {[
          {
            number: "01",
            title:
              "Sosyal Medya Yönetimi",
            text:
              "İçerik stratejisi, kreatif üretim, planlama ve marka iletişimi.",
          },
          {
            number: "02",
            title:
              "Grafik Tasarım",
            text:
              "Kurumsal kimlikten sosyal medya tasarımlarına kadar tutarlı görsel iletişim.",
          },
          {
            number: "03",
            title:
              "Reklam Yönetimi",
            text:
              "Meta reklamları, doğru hedef kitle, optimizasyon ve dönüşüm odaklı kampanyalar.",
          },
        ].map((service) => (
          <article
            key={service.number}
            className="
              min-h-[340px]
              bg-black
              p-7
              sm:p-9
            "
          >
            <span
              className="
                text-[10px]
                tracking-[0.2em]
                text-[var(--wine-light)]
              "
            >
              {service.number}
            </span>

            <h2
              className="
                mt-16
                max-w-[320px]
                font-serif
                text-[clamp(2rem,3vw,3.2rem)]
                leading-[0.95]
                tracking-[-0.045em]
              "
            >
              {service.title}
            </h2>

            <p
              className="
                mt-6
                max-w-[320px]
                text-[14px]
                leading-7
                text-[var(--muted)]
              "
            >
              {service.text}
            </p>
          </article>
        ))}
      </div>
    </DetailPageShell>
  );
}